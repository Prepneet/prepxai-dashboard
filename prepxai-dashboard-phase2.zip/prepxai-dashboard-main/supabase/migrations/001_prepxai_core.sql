-- PrepX Ai · Phase 1 migration
-- Run once in Supabase SQL Editor. Safe to re-run (uses IF NOT EXISTS / OR REPLACE).

-- Refund a doubt when the AI call fails (called by api/doubt.js).
create or replace function public.refund_doubt(uid uuid)
returns void language plpgsql security definer as $$
begin
  update public.doubt_usage set used = greatest(used - 1, 0)
  where user_id = uid and day = current_date;
end $$;

-- Exam change requests: students can create and read only their own.
create table if not exists public.exam_change_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  current_exam text,
  requested_exam text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);
alter table public.exam_change_requests enable row level security;
drop policy if exists "own exam requests insert" on public.exam_change_requests;
create policy "own exam requests insert" on public.exam_change_requests
  for insert with check (auth.uid() = user_id);
drop policy if exists "own exam requests read" on public.exam_change_requests;
create policy "own exam requests read" on public.exam_change_requests
  for select using (auth.uid() = user_id);

-- Feedback submitted from the dashboard (WhatsApp send is manual; this log is for our records).
create table if not exists public.feedback_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  category text not null check (category in ('very_good','okay','not_good','bug','custom')),
  message text check (char_length(message) <= 1000),
  created_at timestamptz not null default now()
);
alter table public.feedback_submissions enable row level security;
drop policy if exists "own feedback insert" on public.feedback_submissions;
create policy "own feedback insert" on public.feedback_submissions
  for insert with check (auth.uid() = user_id);
drop policy if exists "own feedback read" on public.feedback_submissions;
create policy "own feedback read" on public.feedback_submissions
  for select using (auth.uid() = user_id);

-- Webhook matches payments by email, so the column must exist.
alter table public.profiles add column if not exists email text;
create index if not exists profiles_email_idx on public.profiles (lower(email));
